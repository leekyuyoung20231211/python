package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.answer.Answer;
import com.example.demo.answer.AnswerRepository;

@SpringBootTest
public class AnserUpdate {
	@Autowired
	AnswerRepository ar;
	
	@Test
	void update() {
		Optional<Answer> oa = ar.findById(1);
		assertTrue(oa.isPresent());
		Answer a =  oa.get();
		a.setContent("수정된 답변");
		ar.save(a);
	}
}

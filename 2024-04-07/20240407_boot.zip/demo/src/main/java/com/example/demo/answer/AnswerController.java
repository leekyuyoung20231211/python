package com.example.demo.answer;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.question.QuestionService;

import lombok.RequiredArgsConstructor;


@Controller
@RequiredArgsConstructor
public class AnswerController {

	private final AnswerService as;
	private final QuestionService qs;
	
	@PostMapping("answer/create/{id}")
	public String answerCreate(@PathVariable("id") Integer id, Answer answer) {
		answer.setQuestion( qs.getDetail(id)  );
		int result =  as.answerCreate(answer);
		if(result > 0)
			return String.format("redirect:/question/detail/%s", id);
		else
			return null;
	}
	
}

package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.question.QuestioinRepository;
import com.example.demo.question.Question;

@SpringBootTest
public class QuestionDelete {

	@Autowired
	QuestioinRepository rq;
	/**
	 * id = 1인 질문항목을 가져와서.. 리파지토리.delete에 객체를 전달
	 */
	@Test
	void delete() {
		Optional<Question> oq = rq.findById(1);
		assertTrue(oq.isPresent());
		rq.delete(  oq.get() );
	}
}

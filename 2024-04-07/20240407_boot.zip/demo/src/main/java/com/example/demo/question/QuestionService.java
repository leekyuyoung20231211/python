package com.example.demo.question;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class QuestionService {

	private final QuestioinRepository qr;
	public List<Question> findAll() {		
		return qr.findAll();
	}
	public Question getDetail(Integer id) {
		Optional<Question> result = qr.findById(id);
		if(result.isPresent())
			return result.get();
		else
			return null;
	}
	
}

package com.example.demo.answer;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AnswerService {
	private final AnswerRepository ar;

	public int answerCreate(Answer answer) {
		
		ar.save(answer);
		return 1;
	}

}

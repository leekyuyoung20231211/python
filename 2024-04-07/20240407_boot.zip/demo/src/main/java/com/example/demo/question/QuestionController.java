package com.example.demo.question;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import lombok.RequiredArgsConstructor;



@Controller
@RequiredArgsConstructor
public class QuestionController {

//	@Autowired
//	private final QuestioinRepository qr;  // @RequiredArgsConstructor 생성자를 통한 자동주입
	private final QuestionService qs;
	
	@GetMapping("/question/list")
//	@ResponseBody
	public String questionLists(Model model) {
//		return "질문목록 을 만들어야 합니다.";
		List<Question> question_list = qs.findAll(); // 데이터 베이스에서 받아서
		
		
		model.addAttribute("question_list", question_list); // 타임리프에 전달
		return "question_list";
	}
	@GetMapping("/question/detail/{id}")
	public String detail(Model model,@PathVariable("id") Integer id)
	{
		// 서비스 호출
		// 결과 받아서 detail 로 전달
		Question q =  qs.getDetail(id);
		model.addAttribute("detail",q);
		return "question_detail";
	}
	
	
}
